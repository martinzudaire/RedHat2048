library GridCoordinates;

///
/// GRID COORDINATES
/// 
/// Grid coordinates.
/// 
///

class GridCoordinates {
  
  int x;
  int y;  
  
  //Constructor
  GridCoordinates(int x, int y){
    this.x = x;
    this.y = y;
  }
  
}