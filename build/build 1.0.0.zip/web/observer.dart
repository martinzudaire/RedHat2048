library observer; 

///
/// OBSERVER
/// 
/// Abstract.
///

abstract class Observer {
  
  void notify();
  
}